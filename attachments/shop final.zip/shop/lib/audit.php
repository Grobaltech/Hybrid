<?php
// lib/audit.php — shim to avoid duplicate declarations.
// All logic lives in lib/functions.php::audit()
require_once __DIR__ . '/functions.php';

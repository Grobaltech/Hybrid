<?php
// config.php
// Update these for your local XAMPP MySQL setup
define('DB_HOST', '127.0.0.1');
define('DB_NAME', 'php_pos');
define('DB_USER', 'root');
define('DB_PASS', '');

// App settings
define('APP_NAME', 'Hybrid Phone Service Center');
define('BASE_URL', '/shop/public');
?>
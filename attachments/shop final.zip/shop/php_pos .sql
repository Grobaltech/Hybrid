-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 23, 2025 at 01:12 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `php_pos`
--

-- --------------------------------------------------------

--
-- Table structure for table `audit_log`
--

CREATE TABLE `audit_log` (
  `id` bigint(20) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `action` varchar(64) NOT NULL,
  `entity` varchar(64) NOT NULL,
  `entity_id` int(11) DEFAULT NULL,
  `details` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`details`)),
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `audit_logs`
--

CREATE TABLE `audit_logs` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `username` varchar(64) DEFAULT NULL,
  `action` varchar(64) NOT NULL,
  `entity_type` varchar(64) DEFAULT NULL,
  `entity_id` int(11) DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  `page` varchar(64) DEFAULT NULL,
  `ip` varchar(64) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `audit_logs`
--

INSERT INTO `audit_logs` (`id`, `user_id`, `username`, `action`, `entity_type`, `entity_id`, `message`, `page`, `ip`, `user_agent`, `created_at`) VALUES
(1, 1, 'admin', 'auth.login', 'user', 1, NULL, 'login', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36 Edg/141.0.0.0', '2025-10-16 11:51:30'),
(2, 1, 'admin', 'user.delete', 'user', 3, NULL, 'users', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36 Edg/141.0.0.0', '2025-10-16 12:10:55'),
(3, 1, 'Grobaltech', 'auth.login', 'user', 1, NULL, 'login', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36 Edg/141.0.0.0', '2025-10-17 18:56:48'),
(4, 1, 'Grobaltech', 'auth.login', 'user', 1, NULL, 'login', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36 Edg/141.0.0.0', '2025-10-20 20:04:00'),
(5, 1, 'Grobaltech', 'auth.login', 'user', 1, NULL, 'login', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36 Edg/141.0.0.0', '2025-10-22 19:11:43'),
(6, 1, 'Grobaltech', 'user.caps', 'user', 1, '[\"view_costs\"]', 'users', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36 Edg/141.0.0.0', '2025-10-22 19:34:05'),
(7, 1, 'Grobaltech', 'supplier.create', 'supplier', 1, 'name=Grobaltech', 'suppliers', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36 Edg/141.0.0.0', '2025-10-22 22:13:44'),
(8, 1, 'Grobaltech', 'auth.login', 'user', 1, NULL, 'login', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36 Edg/141.0.0.0', '2025-10-22 22:31:29'),
(9, 1, 'Grobaltech', 'purchase.ordered', 'purchase', 1, NULL, 'purchases', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36 Edg/141.0.0.0', '2025-10-22 22:40:32'),
(10, 1, 'Grobaltech', 'purchase.ordered', 'purchase', 2, NULL, 'purchases', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36 Edg/141.0.0.0', '2025-10-22 22:53:07');

-- --------------------------------------------------------

--
-- Table structure for table `creditors`
--

CREATE TABLE `creditors` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `total_credit` decimal(12,2) NOT NULL DEFAULT 0.00,
  `amount_paid` decimal(12,2) NOT NULL DEFAULT 0.00,
  `balance` decimal(12,2) NOT NULL DEFAULT 0.00,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `creditors`
--

INSERT INTO `creditors` (`id`, `name`, `phone`, `description`, `total_credit`, `amount_paid`, `balance`, `created_at`) VALUES
(1, 'Jjuko', '', 'Daily customer', 0.00, 0.00, 0.00, '2025-10-17 17:27:44');

-- --------------------------------------------------------

--
-- Table structure for table `creditor_payments`
--

CREATE TABLE `creditor_payments` (
  `id` int(11) NOT NULL,
  `creditor_id` int(11) NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `paid_at` datetime NOT NULL DEFAULT current_timestamp(),
  `note` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `creditor_payments`
--

INSERT INTO `creditor_payments` (`id`, `creditor_id`, `amount`, `paid_at`, `note`, `created_at`) VALUES
(1, 1, 60000.00, '2025-10-17 17:30:00', 'Screen', '2025-10-17 17:30:31');

-- --------------------------------------------------------

--
-- Table structure for table `credits`
--

CREATE TABLE `credits` (
  `id` int(11) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `sale_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `balance` decimal(10,2) NOT NULL,
  `status` enum('open','closed') NOT NULL DEFAULT 'open',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `credits`
--

INSERT INTO `credits` (`id`, `customer_id`, `sale_id`, `amount`, `balance`, `status`, `created_at`, `updated_at`) VALUES
(1, NULL, 10, 60000.00, 0.00, 'closed', '2025-10-17 14:28:18', NULL),
(2, NULL, 11, 60000.00, 60000.00, 'open', '2025-10-17 19:09:23', NULL),
(3, NULL, 12, 60000.00, 60000.00, 'open', '2025-10-17 19:17:21', NULL),
(4, NULL, 14, 60000.00, 60000.00, 'open', '2025-10-22 20:27:17', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `credit_payments`
--

CREATE TABLE `credit_payments` (
  `id` int(11) NOT NULL,
  `credit_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `paid_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `note` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `credit_payments`
--

INSERT INTO `credit_payments` (`id`, `credit_id`, `amount`, `paid_at`, `note`) VALUES
(1, 1, 25000.00, '2025-10-17 14:28:58', ''),
(2, 1, 35000.00, '2025-10-17 14:31:20', 'Cleared');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `phone` varchar(64) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `expenses`
--

CREATE TABLE `expenses` (
  `id` int(11) NOT NULL,
  `date` date NOT NULL,
  `category` varchar(128) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `note` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `expenses`
--

INSERT INTO `expenses` (`id`, `date`, `category`, `amount`, `note`, `created_at`) VALUES
(1, '2025-10-17', 'Lunch', 45000.00, 'All bills', '2025-10-17 14:33:24');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `sku` varchar(64) NOT NULL,
  `name` varchar(255) NOT NULL,
  `category` varchar(128) DEFAULT NULL,
  `price_cost` decimal(10,2) NOT NULL DEFAULT 0.00,
  `price_sell` decimal(10,2) NOT NULL DEFAULT 0.00,
  `stock` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `quantity` int(11) NOT NULL DEFAULT 0,
  `barcode` varchar(64) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `sku`, `name`, `category`, `price_cost`, `price_sell`, `stock`, `created_at`, `quantity`, `barcode`) VALUES
(1, 'SMA05', 'Samsung Galaxy A05', 'Screens', 45000.00, 60000.00, 29, '2025-10-15 17:16:41', 0, NULL),
(2, 'SMA06', 'Samsung Galaxy A06', 'Screens', 45000.00, 60000.00, 17, '2025-10-15 17:17:42', 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `purchases`
--

CREATE TABLE `purchases` (
  `id` int(11) NOT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `reference` varchar(128) DEFAULT NULL,
  `total_cost` decimal(10,2) NOT NULL DEFAULT 0.00,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `total` decimal(12,2) NOT NULL DEFAULT 0.00,
  `status` enum('ordered','received') NOT NULL DEFAULT 'received',
  `received_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `purchases`
--

INSERT INTO `purchases` (`id`, `supplier_id`, `reference`, `total_cost`, `created_at`, `total`, `status`, `received_at`) VALUES
(1, 1, 'Gtc90487', 420000.00, '2025-10-22 22:40:32', 420000.00, 'ordered', NULL),
(2, 1, 'Gtc90487', 420000.00, '2025-10-22 22:53:07', 420000.00, 'ordered', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `purchase_items`
--

CREATE TABLE `purchase_items` (
  `id` int(11) NOT NULL,
  `purchase_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `packs` int(11) DEFAULT NULL,
  `pack_size` int(11) DEFAULT NULL,
  `unit_cost` decimal(10,2) NOT NULL,
  `line_cost` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `purchase_items`
--

INSERT INTO `purchase_items` (`id`, `purchase_id`, `product_id`, `quantity`, `packs`, `pack_size`, `unit_cost`, `line_cost`) VALUES
(1, 1, 2, 14, 1, 12, 30000.00, 420000.00),
(2, 2, 2, 14, 1, 12, 30000.00, 420000.00);

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `id` int(11) NOT NULL,
  `receipt_no` varchar(32) DEFAULT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `total` decimal(10,2) NOT NULL,
  `total_cost` decimal(10,2) NOT NULL,
  `profit` decimal(10,2) NOT NULL,
  `tax_rate` decimal(5,2) NOT NULL DEFAULT 0.00,
  `tax_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `grand_total` decimal(10,2) NOT NULL DEFAULT 0.00,
  `payment_method` enum('cash','credit') NOT NULL DEFAULT 'cash',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`id`, `receipt_no`, `customer_id`, `total`, `total_cost`, `profit`, `tax_rate`, `tax_amount`, `grand_total`, `payment_method`, `notes`, `created_at`) VALUES
(5, 'RCPT-20251015-000005', NULL, 60000.00, 45000.00, 15000.00, 0.00, 0.00, 0.00, 'cash', NULL, '2025-10-15 17:39:23'),
(6, 'RCPT-20251015-000006', NULL, 720000.00, 540000.00, 180000.00, 0.00, 0.00, 0.00, 'cash', NULL, '2025-10-15 17:40:18'),
(7, 'RCPT-20251015-000007', NULL, 240000.00, 180000.00, 60000.00, 0.00, 0.00, 0.00, 'cash', NULL, '2025-10-15 17:43:15'),
(9, 'RCPT-20251017-000009', NULL, 230000.00, 135000.00, 95000.00, 0.00, 0.00, 230000.00, 'cash', NULL, '2025-10-17 14:25:24'),
(10, 'RCPT-20251017-000010', NULL, 60000.00, 45000.00, 15000.00, 0.00, 0.00, 60000.00, 'credit', NULL, '2025-10-17 14:28:18'),
(11, 'RCPT-20251017-000011', NULL, 60000.00, 45000.00, 15000.00, 0.00, 0.00, 60000.00, 'credit', NULL, '2025-10-17 19:09:23'),
(12, 'RCPT-20251017-000012', NULL, 60000.00, 45000.00, 15000.00, 0.00, 0.00, 60000.00, 'credit', NULL, '2025-10-17 19:17:20'),
(13, 'RCPT-20251022-000013', NULL, 60000.00, 45000.00, 15000.00, 0.00, 0.00, 60000.00, 'cash', NULL, '2025-10-22 20:26:34'),
(14, 'RCPT-20251022-000014', NULL, 60000.00, 45000.00, 15000.00, 0.00, 0.00, 60000.00, 'credit', NULL, '2025-10-22 20:27:17');

-- --------------------------------------------------------

--
-- Table structure for table `sale_items`
--

CREATE TABLE `sale_items` (
  `id` int(11) NOT NULL,
  `sale_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price_sell` decimal(10,2) NOT NULL,
  `actual_price` decimal(12,2) NOT NULL DEFAULT 0.00,
  `price_cost` decimal(10,2) NOT NULL,
  `line_total` decimal(10,2) NOT NULL,
  `line_cost` decimal(10,2) NOT NULL,
  `line_profit` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sale_items`
--

INSERT INTO `sale_items` (`id`, `sale_id`, `product_id`, `quantity`, `price_sell`, `actual_price`, `price_cost`, `line_total`, `line_cost`, `line_profit`) VALUES
(1, 5, 1, 1, 60000.00, 60000.00, 45000.00, 60000.00, 45000.00, 15000.00),
(2, 6, 1, 1, 60000.00, 60000.00, 45000.00, 60000.00, 45000.00, 15000.00),
(3, 6, 2, 11, 60000.00, 60000.00, 45000.00, 660000.00, 495000.00, 165000.00),
(4, 7, 1, 3, 60000.00, 60000.00, 45000.00, 180000.00, 135000.00, 45000.00),
(5, 7, 2, 1, 60000.00, 60000.00, 45000.00, 60000.00, 45000.00, 15000.00),
(7, 9, 1, 1, 60000.00, 60000.00, 45000.00, 60000.00, 45000.00, 15000.00),
(8, 9, 2, 2, 60000.00, 85000.00, 45000.00, 170000.00, 90000.00, 80000.00),
(9, 10, 2, 1, 60000.00, 60000.00, 45000.00, 60000.00, 45000.00, 15000.00),
(10, 11, 2, 1, 60000.00, 60000.00, 45000.00, 60000.00, 45000.00, 15000.00),
(11, 12, 2, 1, 60000.00, 60000.00, 45000.00, 60000.00, 45000.00, 15000.00),
(12, 13, 2, 1, 60000.00, 60000.00, 45000.00, 60000.00, 45000.00, 15000.00),
(13, 14, 1, 1, 60000.00, 60000.00, 45000.00, 60000.00, 45000.00, 15000.00);

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `k` varchar(64) NOT NULL,
  `v` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`k`, `v`) VALUES
('company_address', 'New pioneer Mall shop NO PC 90'),
('company_email', 'hybriphoneservicecenter@gmail.com'),
('company_name', 'Hybrid Phone S/C'),
('company_phone', '0754475028');

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

CREATE TABLE `suppliers` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `phone` varchar(64) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `suppliers`
--

INSERT INTO `suppliers` (`id`, `name`, `phone`, `email`, `created_at`) VALUES
(1, 'Grobaltech', '+256707836076', 'www.babwicos@gmail.com.com', '2025-10-22 22:13:44');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(64) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` enum('admin','manager','cashier') NOT NULL DEFAULT 'cashier',
  `phone` varchar(64) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `national_id` varchar(128) DEFAULT NULL,
  `about` text DEFAULT NULL,
  `photo_path` varchar(255) DEFAULT NULL,
  `id_photo_path` varchar(255) DEFAULT NULL,
  `cv_path` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password_hash`, `role`, `phone`, `email`, `national_id`, `about`, `photo_path`, `id_photo_path`, `cv_path`, `created_at`) VALUES
(1, 'Grobaltech', '$2y$10$TBiNDeNJXjOqwHmMR06P/.GABhYm4gkYCb3OSKNVwaayyfRv.G5G.', 'admin', '+256707836076', 'www.babwicos@gmail.com.com', '', '', 'uploads/users/1.jpg', NULL, NULL, '2025-10-16 08:12:08');

-- --------------------------------------------------------

--
-- Table structure for table `user_caps`
--

CREATE TABLE `user_caps` (
  `user_id` int(11) NOT NULL,
  `cap` varchar(64) NOT NULL,
  `allowed` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user_caps`
--

INSERT INTO `user_caps` (`user_id`, `cap`, `allowed`) VALUES
(1, 'view_costs', 1);

-- --------------------------------------------------------

--
-- Table structure for table `user_page_access`
--

CREATE TABLE `user_page_access` (
  `user_id` int(11) NOT NULL,
  `page` varchar(64) NOT NULL,
  `allowed` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user_page_access`
--

INSERT INTO `user_page_access` (`user_id`, `page`, `allowed`) VALUES
(1, 'products', 1),
(1, 'sales_history', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `audit_log`
--
ALTER TABLE `audit_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `entity_idx` (`entity`,`entity_id`);

--
-- Indexes for table `audit_logs`
--
ALTER TABLE `audit_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user` (`created_at`,`user_id`),
  ADD KEY `idx_action` (`created_at`,`action`);

--
-- Indexes for table `creditors`
--
ALTER TABLE `creditors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `creditor_payments`
--
ALTER TABLE `creditor_payments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `creditor_id` (`creditor_id`,`paid_at`);

--
-- Indexes for table `credits`
--
ALTER TABLE `credits`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_credits_customer` (`customer_id`),
  ADD KEY `idx_credits_sale` (`sale_id`);

--
-- Indexes for table `credit_payments`
--
ALTER TABLE `credit_payments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `credit_id` (`credit_id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_customers_name` (`name`),
  ADD KEY `idx_customers_phone` (`phone`),
  ADD KEY `idx_customers_email` (`email`);

--
-- Indexes for table `expenses`
--
ALTER TABLE `expenses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `sku` (`sku`),
  ADD KEY `idx_products_sku` (`sku`),
  ADD KEY `idx_products_name` (`name`);

--
-- Indexes for table `purchases`
--
ALTER TABLE `purchases`
  ADD PRIMARY KEY (`id`),
  ADD KEY `supplier_id` (`supplier_id`);

--
-- Indexes for table `purchase_items`
--
ALTER TABLE `purchase_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `purchase_id` (`purchase_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uniq_receipt_no` (`receipt_no`),
  ADD KEY `idx_sales_id` (`id`),
  ADD KEY `idx_sales_created` (`created_at`),
  ADD KEY `idx_sales_created_at` (`created_at`),
  ADD KEY `idx_sales_customer` (`customer_id`);

--
-- Indexes for table `sale_items`
--
ALTER TABLE `sale_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sale_id` (`sale_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`k`);

--
-- Indexes for table `suppliers`
--
ALTER TABLE `suppliers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `user_caps`
--
ALTER TABLE `user_caps`
  ADD PRIMARY KEY (`user_id`,`cap`);

--
-- Indexes for table `user_page_access`
--
ALTER TABLE `user_page_access`
  ADD PRIMARY KEY (`user_id`,`page`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `audit_log`
--
ALTER TABLE `audit_log`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `audit_logs`
--
ALTER TABLE `audit_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `creditors`
--
ALTER TABLE `creditors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `creditor_payments`
--
ALTER TABLE `creditor_payments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `credits`
--
ALTER TABLE `credits`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `credit_payments`
--
ALTER TABLE `credit_payments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `expenses`
--
ALTER TABLE `expenses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `purchases`
--
ALTER TABLE `purchases`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `purchase_items`
--
ALTER TABLE `purchase_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `sale_items`
--
ALTER TABLE `sale_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `suppliers`
--
ALTER TABLE `suppliers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `creditor_payments`
--
ALTER TABLE `creditor_payments`
  ADD CONSTRAINT `fk_cp_creditor` FOREIGN KEY (`creditor_id`) REFERENCES `creditors` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `credits`
--
ALTER TABLE `credits`
  ADD CONSTRAINT `credits_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`),
  ADD CONSTRAINT `credits_ibfk_2` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`);

--
-- Constraints for table `credit_payments`
--
ALTER TABLE `credit_payments`
  ADD CONSTRAINT `credit_payments_ibfk_1` FOREIGN KEY (`credit_id`) REFERENCES `credits` (`id`);

--
-- Constraints for table `purchases`
--
ALTER TABLE `purchases`
  ADD CONSTRAINT `purchases_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`);

--
-- Constraints for table `purchase_items`
--
ALTER TABLE `purchase_items`
  ADD CONSTRAINT `purchase_items_ibfk_1` FOREIGN KEY (`purchase_id`) REFERENCES `purchases` (`id`),
  ADD CONSTRAINT `purchase_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);

--
-- Constraints for table `sales`
--
ALTER TABLE `sales`
  ADD CONSTRAINT `sales_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`);

--
-- Constraints for table `sale_items`
--
ALTER TABLE `sale_items`
  ADD CONSTRAINT `sale_items_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`),
  ADD CONSTRAINT `sale_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);

--
-- Constraints for table `user_caps`
--
ALTER TABLE `user_caps`
  ADD CONSTRAINT `user_caps_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `user_page_access`
--
ALTER TABLE `user_page_access`
  ADD CONSTRAINT `user_page_access_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

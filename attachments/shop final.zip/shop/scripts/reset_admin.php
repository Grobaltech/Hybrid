<?php
// scripts/reset_admin.php  (DELETE THIS FILE AFTER RUNNING ONCE)
require_once __DIR__ . '/../lib/db.php';

$username = 'admin';
$newPlain = 'admin123';  // change to your choice if you want

$hash = password_hash($newPlain, PASSWORD_BCRYPT);
$pdo->prepare('INSERT INTO users (username, password_hash, role)
               VALUES (?, ?, "admin")
               ON DUPLICATE KEY UPDATE password_hash=VALUES(password_hash), role=VALUES(role)')
    ->execute([$username, $hash]);

$row = $pdo->prepare('SELECT id, username, role FROM users WHERE username=?');
$row->execute([$username]);
var_dump($row->fetch());
echo "\nOK. Password reset for user 'admin'.";
